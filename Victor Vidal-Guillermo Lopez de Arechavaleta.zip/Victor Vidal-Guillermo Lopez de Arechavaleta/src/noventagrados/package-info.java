/** 
 *         Código correspondiente al juego de mesa Noventa Grados,
 *         segunda parte de la Práctica Obligatoria 2.
 * 
 *         Proyecto desarrollado como parte de la asignatura de Metodología de la 
 * 		   Programación, 2º Grado Ingeniería Informática, Universidad de Burgos.
 *             
 * @author <a href="vvv1005@alu.ubu.es">Víctor Vidal Vivanco</a>
 * @author <a href="glz1001@alu.ubu.es">Guillermo López de Arechavaleta Zapatero</a>        
 * @since 1.0
 * 
 */
package noventagrados;